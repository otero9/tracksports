package com.udc.master.tfm.tracksports.locationtracker;

/**
 * Tipos de proveedores de localizacion utilizados
 * @author a.oteroc
 *
 */
public enum ProviderType {NETWORK, GPS};
