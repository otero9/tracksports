package com.udc.master.tfm.tracksports.bbdd.activity.mapposition;

/**
 * Interfaz de acceso a la relacion entre los ejercicios y las coordenadas
 * @author a.oteroc
 *
 */
public interface ExerciseMapPositionDAO {

}
