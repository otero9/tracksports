package com.udc.master.tfm.tracksports.bbdd.mapposition;

/**
 * Interfaz de acceso a los metodos sobre las coordenadas
 * @author a.oteroc
 *
 */
public interface MapPositionDAO {

}
